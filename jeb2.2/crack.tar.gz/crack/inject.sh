#!/bin/bash
sleep 0.6
pid=`ps -ef|grep 'MacOS/jeb'|grep -v grep|awk '{print $2}'`
#dylib_path=`readlink -f agent.dylib`
dylib_path=`pwd`/agent.dylib
java -jar inject.jar ${pid} ${dylib_path}
